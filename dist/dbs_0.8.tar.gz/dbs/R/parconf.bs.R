#########################################
# Function for calculation of CI and other statistics
# for "dbs" package
# 27.03.2015-21.04.2015
# E.Metelkin
#########################################

parconf.lin<-function(hessian,
                      p.opt,
                      log=FALSE,
                      level=0.95,
                      ...)
{
  # hessian - matrix of second derivative of (-2lnL) for parameters (matrix)
  # p.opt - optimal values armin(-2lnL) (numeric)
  # log   - single value or length(log)=length(p.opt) to use log-normal instead of normal distribution (logical)
  # level - confidence level (numeric between 0 and 1)
  # ...   - other arguments passed to solve()
  
  ### checking arguments
  if (missing(p.opt)) stop("argument p.opt is missing, with no default!")
  if (!any(length(log) == c(1L,length(p.opt)))) stop("length(log) must be equal to length(p.opt) or 1!")
  if (any(p.opt[log]<=0)) stop("p.opt values must be positive for all log marked parameters!")
  ### checking p.opt and hessian
  if (any(eigen(hessian)$values<=0)) stop("argument hessian must be positive-definite matrix!")
  if (!all(attributes(hessian)$dim==length(p.opt))) stop("number of columns and rows in hessian must be the length of p.opt!")
  if (!is.null(attributes(hessian)$dimnames[[2]]))
  {
    if (!all(names(p.opt) %in% attributes(hessian)$dimnames[[2]])) stop("Some p.opt names is not in hessian names!")
    if (!all(attributes(hessian)$dimnames[[2]] %in% names(p.opt))) stop("Some p.opt names is missing!")
    p.opt<-p.opt[match(names(p.opt), attributes(hessian)$dimnames[[2]])]
  }
  
  log<-rep(log, length.out=length(p.opt))
  
  ### calculations
  vmat0 <-base::solve(0.5*hessian,...) # variance matrix
  transform1<-ifelse(log, 1/p.opt, 1)
  p.opt.trans<-ifelse(log, log(p.opt), p.opt); names(p.opt.trans)<-names(p.opt)
  vmat<-diag(transform1) %*% vmat0 %*% diag(transform1)
  sd<-sqrt(diag(vmat))
  err<-qnorm(0.5+level/2)
  left<-ifelse(log, exp(p.opt.trans-err*sd), p.opt.trans-err*sd)
  right<-ifelse(log, exp(p.opt.trans+err*sd), p.opt.trans+err*sd)
  ci=matrix(c(left,right), nrow=2, byrow=T, dimnames=list(paste0(100*c((1-level)/2, (1+level)/2),"%"), names(p.opt)))
  
  return(list(ci=ci, level=level, log=log, p.opt=p.opt,  variance=vmat, correlation=cov2cor(vmat), sd=sd)) # resulted data.frame
}

parconf.bs<-function(p.set,
                    log=FALSE,
                    level=0.95,
                    norm.test=shapiro.test,
                    ...)
{
  # p.set -  data.frame with parameter set (data.frame)
  # log   - single value or length(log)=length(p.set) to use log-normal instead of normal distribution (logical)
  # level - confidence level (numeric between 0 and 1)
  # norm.test - function to check normality (function)
  # ...   -  other arguments passed to quantile()
  
  if (!any(length(log) == c(1L,length(p.set)))) stop("length(log) must be equal to length(p.set) or 1!")
  log<-rep(log, length.out=length(p.set))
  if (any(log))
    if (any(p.set[,log]<=0)) stop("p.set values must be positive for all log marked parameters!")
  
  ### calculations
  ci<-sapply(p.set, stats::quantile, probs=c((1-level)/2,(1+level)/2),...)
  median<-sapply(p.set, stats::median)
    
  ### logarythmic column if needed
  p.set.mod<-p.set
  p.set.mod[log]<-log(p.set[log])
  
  ### variance
  vmat<-stats::var(p.set.mod)
  
  ### normality test
  if (!is.null(norm.test))
  {
    normality<-sapply(p.set.mod, norm.test)
  } else {
    normality<-NULL
  }

  return(list(ci=ci, level=level, log=log, median=median, variance=vmat, normality=normality))
}