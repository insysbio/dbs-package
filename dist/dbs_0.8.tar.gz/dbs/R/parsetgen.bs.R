#########################################
# Function for generation of parameter set for DBSolve output
# for "dbs" package
# 24.03.2015-14.04.2015
# A.Alekseev, E.Metelkin
#########################################

parsetgen.lin<-function(hessian,
                        p.opt,
                        conditions=data.frame(),
                        independent=FALSE,
                        samples=1024,
                        append.opt=FALSE,
                        log=FALSE,
                        method=c("eigen", "svd", "chol"),
                        ... # arguments for hessian
)
{
  # hessian - matrix of second derivative of (-2lnL) for parameters (matrix)
  # p.opt - optimal values armin(-2lnL) (numeric)
  # conditions - conditions of the simulations (data.frame)
  # independent - is each subset independent? (logical)
  # samples    - number of resulted samples for each condition (integer)
  # log   - single value or length(log)=length(p.opt) to use log-normal instead of normal distribution (logical)
  # append.opt - append optimal values to the dataset (logical)
  # method - argument for rmvnorm (character)
  # ...    - other arguments passed to solve
  
  ### checking libraries  
  if (!requireNamespace("mvtnorm", quietly=T)) stop("Install \'mvtnorm\' package!")
  ### checking arguments
  if (missing(p.opt)) stop("argument p.opt is missing, with no default!")
  if (any(eigen(hessian)$values<0)) stop("argument hessian must be non-negative-definite matrix!")
  if (!any(length(log) == c(1L,length(p.opt)))) stop("length(log) must be equal to length(p.opt) or 1!")
  if (any(p.opt[log]<=0)) stop("p.opt values must be positive for all log marked parameters!")
  log<-rep(log, length.out=length(p.opt))
  ### checking p.opt and hessian
  if (!all(attributes(hessian)$dim==length(p.opt))) stop("Size of p.opt does not match the hessian!")
  if (!is.null(attributes(hessian)$dimnames[[2]]))
  {
    if (!all(names(p.opt) %in% attributes(hessian)$dimnames[[2]])) stop("Some p.opt names is not in hessian names!")
    if (!all(attributes(hessian)$dimnames[[2]] %in% names(p.opt))) stop("Some p.opt names is missing!")
    p.opt<-p.opt[match(names(p.opt), attributes(hessian)$dimnames[[2]])]
  }

  ### calculations
  vmat0 <-base::solve(0.5*hessian,...) # variance matrix
  transform1<-ifelse(log, 1/p.opt, 1)
  p.opt.trans<-ifelse(log, log(p.opt), p.opt); names(p.opt.trans)<-names(p.opt)
  vmat<-diag(transform1) %*% vmat0 %*% diag(transform1)
  
  if(!independent | length(conditions)==0) # creation of random values columns
  {
    temp1<-mvtnorm::rmvnorm(n=samples, mean=p.opt.trans, sigma=vmat, method=method)
  } else {
    temp1<-mvtnorm::rmvnorm(n=samples*nrow(conditions), mean=p.opt.trans, sigma=vmat, method=method) # matrix of random parameters
  }
  temp1[,log]<-exp(temp1[,log]) #back transformation of parameters
  
  out<-parsetgen.bs(p.set=as.data.frame(temp1), p.opt=p.opt, conditions=conditions, independent=independent, samples=samples, append.opt=append.opt)
  return(out) # resulted data.frame
}

parsetgen.bs<-function(p.set,
                    p.opt,
                    conditions=data.frame(),
                    independent=FALSE,
                    samples=1024,
                    append.opt=FALSE
)
{
  # p.set -  data.frame with parameter set (data.frame)
  # p.opt - optimal values armin(-2lnL) (numeric, optional if append.opt=F)
  # conditions - conditions of the simulations (data.frame)
  # independent - is each subset independent? (logical)
  # samples    - number of resulted samples for each condition (integer)
  # append.opt - append optimal values to the dataset (logical)
  
  ### checking arguments
  if (missing(p.set)) stop("Argument p.set is missing with no defaults!")
  if (append.opt)
  {
    if (missing(p.opt)) stop("Argument p.opt must be declared if append.opt=T!")
    if (any(is.null(names(p.opt)))) stop("Names of the p.opt must be declared!")
    if (!all(names(p.opt) %in% names(p.set))) stop("Some p.opt names is not in p.set names!")
    if (!all(names(p.set) %in% names(p.opt))) stop("Some p.opt names is missing!")
    p.opt.m<-p.opt[match(names(p.opt), names(p.set))]
  }
  
  
  if (samples>nrow(p.set)) stop("Number of rows in parameter set (",nrow(p.set),") must not be lower than samples number (",samples,")!")
  if (samples*nrow(conditions)>nrow(p.set) & independent) stop("Number of rows in parameter set(",nrow(p.set),") for independent must not be lower than samples number multiplied by conditions number (",samples,"). try independent=F!")
  
  ### calculations
  if(length(conditions)==0) # creation of conditions columns
  {
    ncond<-1
    temp1<-p.set[1:samples,]
    out0<-cbind(nos=1:samples, temp1) # combining parameters and conditions in single
    if (append.opt)
    {
      out0<-cbind(out0,isopt=0)
      temp3<-data.frame(nos=samples+1, t(p.opt.m), isopt=1)
      out0<-rbind(out0,temp3)
    }   
  } else {
    ncond<-nrow(conditions)
    temp2<-sapply(conditions, rep, each=samples) #condition part
    temp1<-if (independent) p.set[1:(samples*nrow(conditions)),] else sapply(p.set[1:samples,], rep, nrow(conditions))
    out0<-cbind(nos=1:(samples*nrow(conditions)), temp1,temp2) # combining parameters and conditions in single
    if (append.opt)
    {
      out0<-cbind(out0,isopt=0)
      temp3<-data.frame(nos=samples*nrow(conditions)+1:nrow(conditions), t(p.opt.m),conditions, isopt=1)
      out0<-rbind(out0,temp3)
    }   
  }
  
  return(out0) # resulted data.frame
}