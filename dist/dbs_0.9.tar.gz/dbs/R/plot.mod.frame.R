#########################################
# Function for confidence intervals plot
# for "dbs" package
# 28.01.2015-06.09.2015
# A.Alekseev, E.Metelkin
#########################################

mod.frame.to.pdf <- function (x, ...,
                              file="mod.frame.to.pdf",
                              cell.width=5,
                              cell.height=5)
{
  ### argument check
  if (!("mod.frame" %in% class(x))) stop("x argument bust be of class mod.frame!")
  argList<-list(...)
  if (is.null(argList$transpose))
    transpose=F
  else
    transpose=argList$transpose
  
  nrow<-ifelse(!transpose, length(unique(x$group)), length(unique(x$var_id)))
  ncol<-ifelse(!transpose, length(unique(x$var_id)), length(unique(x$group)))
  
  pdf(file=file, width=ncol*cell.width, height=nrow*cell.height)
  plot.mod.frame(x, ...)
  dev.off()
}

plot.mod.frame <- function (x,
                            transpose=F,
                            type="l",
                            col="black",
                            lty=1,
                            pch=NA,
                            log="",
                            ...)
{
  
  # Function parameters:
  # x      - calculated confidence intervals and optimal values (mod.frame)
  # transpose - transpose the plot frame (logical)
  # type - single value or vector to draw the line of particular type, see plot (character/integer)
  # col - single value or vector to draw the line of particular color, see plot (character/integer)
  # lty - single value or vector to draw the line of particular line type, see plot (character/integer)
  # pch - single value or vector to draw the line of particular point type, see plot (character/integer)
  # log - logarythmic scales (character)
  
  ###designation
  x$group<-as.factor(x$group)
  facLev<-levels(x$group)
  facTitle<-attributes(x)$group.title
  x$var_id<-as.factor(x$var_id)
  outLev<-levels(x$var_id)
  outTitle<-attributes(x)$var.title
  outCol<-which(attributes(x)$col.def %in% c("quantile", "simulation"))
  inCol<-which(attributes(x)$col.def=="input")
  
  #print(scale.var.max)
  vec_type<-rep_len(type,length(outCol))
  vec_col<-rep_len(col,length(outCol))
  vec_lty<-rep_len(lty,length(outCol))
  vec_pch<-rep_len(pch,length(outCol))

  ### plotting
  if (!transpose) par(mfrow=c(length(facLev),length(outLev))) else par(mfrow=c(length(outLev), length(facLev)))
  
  for (i in seq_along(outLev))
  {
    for (j in seq_along(facLev))
    {
      temp1<-subset(x, var_id==outLev[i] & group==facLev[j])
      if (!transpose) par(mfg=c(j,i)) else par(mfg=c(i,j))
      
      if (nrow(temp1)==0) {
        graphics::plot(c(-1,1), c(1,-1), col="red", type="l", axes=F, xlab="", ylab="", lwd=6)
        graphics::points(c(-1,1), c(-1,1), col="red", type="l", lwd=6)
      } else {
        usex<-if (any(log %in% c("x","xy")))  temp1[,inCol[1]]>0 else T
        usey<-if (any(log %in% c("y","xy")))  as.matrix(temp1[,outCol])>0 else T
        xrange<-range(temp1[usex,inCol[1]], na.rm=T)
        yrange<-range(as.matrix(temp1[,outCol])[usey], na.rm=T)
        graphics::plot(1, 1, type="n", xlab=attributes(x)$col.title[1], ylab=outTitle[i], main=facTitle[j], xlim=xrange, ylim=yrange, log=log, ...)
        for (k in seq_along(outCol))
          graphics::points(temp1[,inCol[1]], temp1[,outCol[k]],
                type=vec_type[k], col=vec_col[k], lty=vec_lty[k], pch=vec_pch[k],
                lwd=ifelse(attributes(x)$col.def[outCol[k]]=="simulation", 3,1))
        graphics::legend(x="topright",legend=attributes(x)$col.title[outCol],  pch=vec_pch, col=vec_col, bg="white", lty=vec_lty, lwd=ifelse(attributes(x)$col.def[outCol]=="simulation", 3,1))
      }
    }
  }  
}
