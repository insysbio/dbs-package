#########################################
# Function to make subset from mod.frame
# for "dbs" package
# 03.08.2015
# E.Metelkin
#########################################

subset.mod.frame<-function(x, subset, drop = FALSE, ...)
{
  # code taken from subset.data.frame
  r <- if (missing(subset)) 
    rep_len(TRUE, nrow(x))
  else {
    e <- substitute(subset)
    r <- eval(e, x, parent.frame())
    if (!is.logical(r)) 
      stop("'subset' must be logical")
    r & !is.na(r)
  }
  res<-x[r, TRUE, drop = drop]
  # end
  
  attr(res, "col.def")<-attr(x, "col.def")
  attr(res, "col.title")<-attr(x, "col.title")
  #
  new.var.title.num<-match(unique(res$var_id), unique(x$var_id))
  attr(res, "var.title")<-attr(x, "var.title")[new.var.title.num]
  new.group.title.num<-match(unique(res$group), unique(x$group))
  attr(res, "group.title")<-attr(x, "group.title")[new.group.title.num]
  #
  return(res)
}
